from django.conf import settings
from django import forms
from django.http import HttpResponse
from django_mako_plus.controller import view_function
from .. import dmp_render, dmp_render_to_response
from base_app.models import MyUser

@view_function
def process_request(request):

	form = UploaderForm()

	template_vars = {
		'form': form
	}
	return dmp_render_to_response(request, 'fileUpload.html', template_vars)

@view_function
def upload(request):
	print('>>>>>>>>>>>>>>>', request.GET)
	print('>>>>>>>>>>>>>>>', request.FILES)
	print('>>>>>>>>>>>>>>>', request.POST[' filename'])

	fh = open("imageToSave.png", "wb")
	fh.write(request.POST[' filename'].decode('base64'))
	fh.close()

	return HttpResponse('1')

class UploaderForm(forms.Form):
	name = forms.CharField()
	upload_file = forms.FileField()