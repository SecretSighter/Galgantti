# -*- coding:ascii -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1425444020.529046
_enable_loop = True
_template_filename = '/vagrant/Galgantti/projects/templates/imageGallery.html'
_template_uri = 'imageGallery.html'
_source_encoding = 'ascii'
import os, os.path, re
_exports = [u'main_center_content']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, u'base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def main_center_content():
            return render_main_center_content(context._locals(__M_locals))
        __M_writer = context.writer()
        __M_writer(u'\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'main_center_content'):
            context['self'].main_center_content(**pageargs)
        

        return ''
    finally:
        context.caller_stack._pop_frame()


def render_main_center_content(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def main_center_content():
            return render_main_center_content(context)
        __M_writer = context.writer()
        __M_writer(u'\r\n    <div class="container extraHeight">\r\n        <div class="row">\r\n            <div id="image_gallery_container">\r\n                <div class="oneImageDiv">\r\n                    <img filename="image1.jpg" size="160px" mime_type="jpg" title="Princess" src="/static/projects/media/image1.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image2.jpg" size="160px" mime_type="jpg" title="Green Monster" src="/static/projects/media/image2.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image3.jpg" size="160px" mime_type="jpg" title="Woody" src="/static/projects/media/image3.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image4.jpg" size="160px" mime_type="jpg" title="Fluffy!" src="/static/projects/media/image4.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image5.jpg" size="160px" mime_type="jpg" title="Angry Old Man" src="/static/projects/media/image5.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image6.jpg" size="160px" mime_type="jpg" title="Up!" src="/static/projects/media/image6.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image7.jpg" size="160px" mime_type="jpg" title="Lightening McQueen" src="/static/projects/media/image7.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image8.jpg" size="160px" mime_type="jpg" title="Bouncy Ball" src="/static/projects/media/image8.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image9.jpg" size="160px" mime_type="jpg" title="Wall-E" src="/static/projects/media/image9.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image10.jpg" size="160px" mime_type="jpg" title="Little Fish" src="/static/projects/media/image10.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image11.jpg" size="160px" mime_type="jpg" title="Cars Logo" src="/static/projects/media/image11.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image12.jpg" size="160px" mime_type="jpg" title="Woody and Buzz" src="/static/projects/media/image12.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image13.jpg" size="160px" mime_type="jpg" title="Angry Grasshopper" src="/static/projects/media/image13.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image14.jpg" size="160px" mime_type="jpg" title="Cube of Pixar!" src="/static/projects/media/image14.jpg" />\r\n                </div>\r\n                <div class="oneImageDiv">\r\n                    <img filename="image15.jpg" size="160px" mime_type="jpg" title="DinoChoper" src="/static/projects/media/image15.jpg" />\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "ascii", "line_map": {"56": 50, "34": 1, "27": 0, "44": 3, "50": 3}, "uri": "imageGallery.html", "filename": "/vagrant/Galgantti/projects/templates/imageGallery.html"}
__M_END_METADATA
"""
