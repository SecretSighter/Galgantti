# -*- coding:ascii -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1425480720.172722
_enable_loop = True
_template_filename = u'/vagrant/Galgantti/base_app/templates/base.htm'
_template_uri = u'base.htm'
_source_encoding = 'ascii'
import os, os.path, re
_exports = [u'main_center_content', u'header', u'title']


from django_mako_plus.controller import static_files 

import datetime 

def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def main_center_content():
            return render_main_center_content(context._locals(__M_locals))
        def title():
            return render_title(context._locals(__M_locals))
        self = context.get('self', UNDEFINED)
        request = context.get('request', UNDEFINED)
        def header():
            return render_header(context._locals(__M_locals))
        def __M_anon_239():
            __M_caller = context.caller_stack._push_frame()
            try:
                __M_writer = context.writer()
                __M_writer(u'\r\n    <div class="container">\r\n        <div class="row">\r\n            Copyright ')
                __M_writer(unicode( datetime.datetime.now().strftime("%b-%Y") ))
                __M_writer(u' Galgantti Confederation\r\n        </div>\r\n    </div>\r\n  ')
                return ''
            finally:
                context.caller_stack._pop_frame()
        __M_writer = context.writer()
        __M_writer(u'\r\n')
        __M_writer(u'\r\n')
        __M_writer(u'\r\n')
        static_renderer = static_files.StaticRenderer(self) 
        
        __M_locals_builtin_stored = __M_locals_builtin()
        __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['static_renderer'] if __M_key in __M_locals_builtin_stored]))
        __M_writer(u'\r\n\r\n<!DOCTYPE html>\r\n<html>\r\n  <meta charset="UTF-8">\r\n  <meta http-equiv="X-UA-COMPATIBLE" content="IE=edge">\r\n  <meta name="viewport" content="width=device-width, initial-scale=1">\r\n\r\n  <head>\r\n    <title>\r\n      ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'title'):
            context['self'].title(**pageargs)
        

        __M_writer(u'\r\n    </title>\r\n  \r\n')
        __M_writer(u'    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">\r\n\r\n')
        __M_writer(u'    ')
        __M_writer(unicode( static_renderer.get_template_css(request, context)  ))
        __M_writer(u'\r\n\r\n  </head>\r\n  <body>\r\n  \r\n  ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'header'):
            context['self'].header(**pageargs)
        

        __M_writer(u'\r\n\r\n  ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'main_center_content'):
            context['self'].main_center_content(**pageargs)
        

        __M_writer(u'\r\n\r\n  ')
        __M_anon_239()
        __M_writer(u'\r\n\r\n')
        __M_writer(u'    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>\r\n    <script src="http://code.jquery.com/ui/1.11.3/jquery-ui.min.js"></script>\r\n\r\n')
        __M_writer(u'    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>\r\n    <script src="/static/base_app/scripts/docs.min.js"></script>\r\n\r\n')
        __M_writer(u'    ')
        __M_writer(unicode( static_renderer.get_template_js(request, context)  ))
        __M_writer(u'\r\n  \r\n  </body>\r\n</html>')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_main_center_content(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def main_center_content():
            return render_main_center_content(context)
        __M_writer = context.writer()
        __M_writer(u'\r\n    <div class="container-fluid">\r\n      <div class="row">\r\n        <div class="col-sm-3 col-md-2 sidebar">\r\n          <ul class="nav nav-sidebar">\r\n            <li class="active"><a href="#">Overview <span class="sr-only">(current)</span></a></li>\r\n            <li><a href="#">Reports</a></li>\r\n            <li><a href="#">Analytics</a></li>\r\n            <li><a href="#">Export</a></li>\r\n          </ul>\r\n          <ul class="nav nav-sidebar">\r\n            <li><a href="">Nav item</a></li>\r\n            <li><a href="">Nav item again</a></li>\r\n            <li><a href="">One more nav</a></li>\r\n            <li><a href="">Another nav item</a></li>\r\n            <li><a href="">More navigation</a></li>\r\n          </ul>\r\n          <ul class="nav nav-sidebar">\r\n            <li><a href="">Nav item again</a></li>\r\n            <li><a href="">One more nav</a></li>\r\n            <li><a href="">Another nav item</a></li>\r\n          </ul>\r\n        </div>\r\n        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">\r\n          <h1 class="page-header">Dashboard</h1>\r\n\r\n          <div class="row placeholders">\r\n            <div class="col-xs-6 col-sm-3 placeholder">\r\n              <img data-src="holder.js/200x200/auto/sky" class="img-responsive" alt="Generic placeholder thumbnail">\r\n              <h4>Label</h4>\r\n              <span class="text-muted">Something else</span>\r\n            </div>\r\n            <div class="col-xs-6 col-sm-3 placeholder">\r\n              <img data-src="holder.js/200x200/auto/vine" class="img-responsive" alt="Generic placeholder thumbnail">\r\n              <h4>Label</h4>\r\n              <span class="text-muted">Something else</span>\r\n            </div>\r\n            <div class="col-xs-6 col-sm-3 placeholder">\r\n              <img data-src="holder.js/200x200/auto/sky" class="img-responsive" alt="Generic placeholder thumbnail">\r\n              <h4>Label</h4>\r\n              <span class="text-muted">Something else</span>\r\n            </div>\r\n            <div class="col-xs-6 col-sm-3 placeholder">\r\n              <img data-src="holder.js/200x200/auto/vine" class="img-responsive" alt="Generic placeholder thumbnail">\r\n              <h4>Label</h4>\r\n              <span class="text-muted">Something else</span>\r\n            </div>\r\n          </div>\r\n\r\n          <h2 class="sub-header">Section title</h2>\r\n          <div class="table-responsive">\r\n            <table class="table table-striped">\r\n              <thead>\r\n                <tr>\r\n                  <th>#</th>\r\n                  <th>Header</th>\r\n                  <th>Header</th>\r\n                  <th>Header</th>\r\n                  <th>Header</th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                <tr>\r\n                  <td>1,001</td>\r\n                  <td>Lorem</td>\r\n                  <td>ipsum</td>\r\n                  <td>dolor</td>\r\n                  <td>sit</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,002</td>\r\n                  <td>amet</td>\r\n                  <td>consectetur</td>\r\n                  <td>adipiscing</td>\r\n                  <td>elit</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,003</td>\r\n                  <td>Integer</td>\r\n                  <td>nec</td>\r\n                  <td>odio</td>\r\n                  <td>Praesent</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,003</td>\r\n                  <td>libero</td>\r\n                  <td>Sed</td>\r\n                  <td>cursus</td>\r\n                  <td>ante</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,004</td>\r\n                  <td>dapibus</td>\r\n                  <td>diam</td>\r\n                  <td>Sed</td>\r\n                  <td>nisi</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,005</td>\r\n                  <td>Nulla</td>\r\n                  <td>quis</td>\r\n                  <td>sem</td>\r\n                  <td>at</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,006</td>\r\n                  <td>nibh</td>\r\n                  <td>elementum</td>\r\n                  <td>imperdiet</td>\r\n                  <td>Duis</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,007</td>\r\n                  <td>sagittis</td>\r\n                  <td>ipsum</td>\r\n                  <td>Praesent</td>\r\n                  <td>mauris</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,008</td>\r\n                  <td>Fusce</td>\r\n                  <td>nec</td>\r\n                  <td>tellus</td>\r\n                  <td>sed</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,009</td>\r\n                  <td>augue</td>\r\n                  <td>semper</td>\r\n                  <td>porta</td>\r\n                  <td>Mauris</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,010</td>\r\n                  <td>massa</td>\r\n                  <td>Vestibulum</td>\r\n                  <td>lacinia</td>\r\n                  <td>arcu</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,011</td>\r\n                  <td>eget</td>\r\n                  <td>nulla</td>\r\n                  <td>Class</td>\r\n                  <td>aptent</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,012</td>\r\n                  <td>taciti</td>\r\n                  <td>sociosqu</td>\r\n                  <td>ad</td>\r\n                  <td>litora</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,013</td>\r\n                  <td>torquent</td>\r\n                  <td>per</td>\r\n                  <td>conubia</td>\r\n                  <td>nostra</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,014</td>\r\n                  <td>per</td>\r\n                  <td>inceptos</td>\r\n                  <td>himenaeos</td>\r\n                  <td>Curabitur</td>\r\n                </tr>\r\n                <tr>\r\n                  <td>1,015</td>\r\n                  <td>sodales</td>\r\n                  <td>ligula</td>\r\n                  <td>in</td>\r\n                  <td>libero</td>\r\n                </tr>\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  ')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_header(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def header():
            return render_header(context)
        __M_writer = context.writer()
        __M_writer(u'\r\n    <nav class="navbar navbar-inverse navbar-fixed-top">\r\n      <div class="container-fluid">\r\n        <div class="navbar-header">\r\n          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">\r\n            <span class="sr-only">Toggle navigation</span>\r\n            <span class="icon-bar"></span>\r\n            <span class="icon-bar"></span>\r\n            <span class="icon-bar"></span>\r\n          </button>\r\n          <a class="navbar-brand" href="/projects/imageGallery">Galgantti</a>\r\n        </div>\r\n        <div id="navbar" class="navbar-collapse collapse">\r\n          <ul class="nav navbar-nav navbar-right">\r\n            <li><a href="/">Dashboard</a></li>\r\n            <li><a href="#">Settings</a></li>\r\n            <li><a href="#">Profile</a></li>\r\n            <li><a href="#">Help</a></li>\r\n          </ul>\r\n          <form class="navbar-form navbar-right">\r\n            <input type="text" class="form-control" placeholder="Search...">\r\n          </form>\r\n        </div>\r\n      </div>\r\n    </nav>\r\n  ')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_title(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def title():
            return render_title(context)
        __M_writer = context.writer()
        __M_writer(u'\r\n        Homepage\r\n      ')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"source_encoding": "ascii", "line_map": {"16": 4, "18": 5, "20": 0, "36": 239, "37": 242, "38": 242, "43": 2, "44": 4, "45": 5, "46": 6, "50": 6, "55": 18, "56": 22, "57": 25, "58": 25, "59": 25, "64": 55, "69": 237, "71": 245, "72": 248, "73": 252, "74": 256, "75": 256, "76": 256, "82": 57, "88": 57, "94": 30, "100": 30, "106": 16, "112": 16, "118": 112}, "uri": "base.htm", "filename": "/vagrant/Galgantti/base_app/templates/base.htm"}
__M_END_METADATA
"""
