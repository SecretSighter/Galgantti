$(function(){

  $('#id_upload_file').off('change.uploader').on('change.uploader', function(){
    var fd = new FormData();
    var file = $(this).get(0).files[0];
    fd.append('uploadfile', file);

    $.ajax({
      processData: false,
      type: 'POST',
      url: '/projects/fileUpload.upload/',
      data: fd,
      xhr: function(){
        var xhr = jQuery.ajaxSettings.xhr();
        if(xhr.upload){
          xhr.upload.addEventListener('progress', function(evt){
            console.log('bound');
            if(evt.lengthComputable){
              console.log(evt);
              //update ui
            }//if
          });//add event listener
        }//if
        return xhr;
      }//xhr
    });//ajax
  });

  
 

});
