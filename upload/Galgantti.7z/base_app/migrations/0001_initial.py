# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='BaseModel',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('date_created', models.DateTimeField(auto_now_add=True)),
                ('last_modified', models.DateTimeField(auto_now=True)),
                ('is_deleted', models.BooleanField(default=False)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Attachment',
            fields=[
                ('basemodel_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='base_app.BaseModel')),
                ('text', models.TextField(max_length=300)),
                ('attachment_url', models.TextField(max_length=50)),
            ],
            options={
            },
            bases=('base_app.basemodel',),
        ),
        migrations.CreateModel(
            name='Collaborator',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('email_address', models.TextField(max_length=100)),
                ('first_name', models.TextField(max_length=50)),
                ('last_name', models.TextField(max_length=50)),
                ('profile_picture', models.TextField(max_length=100)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Comment',
            fields=[
                ('basemodel_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='base_app.BaseModel')),
                ('text', models.TextField(max_length=300)),
            ],
            options={
            },
            bases=('base_app.basemodel',),
        ),
        migrations.CreateModel(
            name='Configuration',
            fields=[
                ('basemodel_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='base_app.BaseModel')),
                ('key', models.TextField(max_length=50)),
                ('value', models.TextField(max_length=50)),
            ],
            options={
            },
            bases=('base_app.basemodel',),
        ),
        migrations.CreateModel(
            name='MyUser',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('first_name', models.TextField(max_length=100)),
                ('last_name', models.TextField(max_length=100)),
                ('salary', models.IntegerField()),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Picture',
            fields=[
                ('basemodel_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='base_app.BaseModel')),
                ('filename', models.TextField(max_length=100)),
                ('size', models.IntegerField()),
                ('mime_type', models.TextField(max_length=100)),
                ('title', models.TextField(max_length=100)),
            ],
            options={
            },
            bases=('base_app.basemodel',),
        ),
        migrations.CreateModel(
            name='Priority',
            fields=[
                ('basemodel_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='base_app.BaseModel')),
                ('name', models.TextField(max_length=40)),
                ('order', models.IntegerField()),
            ],
            options={
            },
            bases=('base_app.basemodel',),
        ),
        migrations.CreateModel(
            name='Project',
            fields=[
                ('basemodel_ptr', models.OneToOneField(parent_link=True, auto_created=True, primary_key=True, serialize=False, to='base_app.BaseModel')),
                ('name', models.TextField(max_length=100)),
                ('description', models.TextField(max_length=300)),
                ('users', models.ManyToManyField(to='base_app.Collaborator')),
            ],
            options={
            },
            bases=('base_app.basemodel',),
        ),
        migrations.CreateModel(
            name='Task',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.TextField(max_length=100)),
                ('start_date', models.DateTimeField()),
                ('end_date', models.DateTimeField()),
                ('parent_task', models.ForeignKey(to='base_app.Task')),
                ('priority', models.ForeignKey(to='base_app.Priority')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Task_history',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('text', models.TextField(max_length=100)),
                ('task_id', models.ForeignKey(to='base_app.Task')),
                ('user_id', models.ForeignKey(to='base_app.Collaborator')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='configuration',
            name='project_id',
            field=models.ForeignKey(to='base_app.Project'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='comment',
            name='task_id',
            field=models.ForeignKey(to='base_app.Task'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='comment',
            name='user_id',
            field=models.ForeignKey(to='base_app.Collaborator'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='attachment',
            name='task_id',
            field=models.ForeignKey(to='base_app.Task'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='attachment',
            name='user_id',
            field=models.ForeignKey(to='base_app.Collaborator'),
            preserve_default=True,
        ),
    ]
